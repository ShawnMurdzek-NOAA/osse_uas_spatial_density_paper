
# Redo MET verification

# Inputs
verif_types=( "additional_2D" "lower_atm" "precip_radar" "severe_wx_env" "sfc" "upper_air" "./ceil/verif/ceil" "./ceil/verif/ceil_exp2" )
example_dir="../spring/"

# Delete old verification
for v in ${verif_types[@]}; do
  rm -rf ${v}
done

# Copy over example make_submit scripts
old_scripts=`ls make_submit*`
for s in ${old_scripts[@]}; do
  mv ${s} ${s}_OLD
done

cd ./ceil/verif
old_scripts=`ls make_submit*`
for s in ${old_scripts[@]}; do
  mv ${s} ${s}_OLD
done
cd ../../

cp ${example_dir}/make_submit*sh .
cp ${example_dir}/ceil/verif/make_submit*sh ./ceil/verif/
